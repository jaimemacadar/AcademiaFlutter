CREATE TABLE pais(
    id int primary key NOT null AUTO_INCREMENT,
    nome varchar(200)
);

INSERT INTO pais(id, nome) VALUES (null,'Brasil');

CREATE TABLE estado(
	id_uf int primary key,
    nome_uf varchar(200)
);

CREATE TABLE cidade(
	id_uf int,
    id_cidade int,
    nome_cidade varchar(200)
);

CREATE TABLE cidade(
	id_pais int,
    id_estado int,
    id_cidade int,
    nome_cidade varchar(200),
    FOREIGN KEY (id_estado) REFERENCES estado(id_uf),
    FOREIGN KEY (id_pais) REFERENCES pais(id)
);
