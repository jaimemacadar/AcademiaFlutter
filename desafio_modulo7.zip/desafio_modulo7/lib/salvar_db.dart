import 'package:mysql1/mysql1.dart';

Future<MySqlConnection> getConnection() async {
  var settings = ConnectionSettings(
  host: 'localhost', 
  port: 3306,
  user: 'root',
  //password: ,
  db: 'bd_desafio_modulo7',
);
return await MySqlConnection.connect(settings);
}

Future<String> salvarEstado(int id_uf, String nome_uf) async {
  var conn = await getConnection();
  var resultado = await conn.query('INSERT INTO estado (id_uf, nome_uf) VALUES (?,?)', [id_uf,nome_uf]);
  if(resultado.affectedRows>0){
    await conn.close();
    return 'Estado adicionado com sucesso';
  }else{
    await conn.close();
    return 'Conexão com banco de dados fechada';
  }
}

Future<String> salvarCidade(int id_pais, int id_estado, int id_cidade, String nome_cidade) async {
  var conn = await getConnection();
  var resultado = await conn.query(
    'INSERT INTO cidade (id_pais, id_estado, id_cidade, nome_cidade) VALUES (?,?,?,?)', 
    [id_pais, id_estado, id_cidade, nome_cidade]
    );
  if(resultado.affectedRows>0){
    await conn.close();
    return 'Cidade adicionada com sucesso';
  }else{
    await conn.close();
    return 'Conexão com banco de dados fechada';
  }
}

