import 'package:dio/dio.dart';
import 'package:desafio_modulo7/salvar_db.dart' as salvar_db;


var numEstados=0;
var listaIdEstados =[];

Future<void> obterEstadosCidades() async {
  var url = 'https://servicodados.ibge.gov.br/api/v1/localidades/estados';
  var dio = Dio();
  var response = await dio.get(url);
  List<dynamic> respData = response.data;
  await Future.forEach(respData, (element) async {
    listaIdEstados.add(element['id']);
    //print('id = ${element['id']} e Estado = ${element['nome']}');
    await salvar_db.salvarEstado(element['id'], element['nome']);
  });
  for(var listaEstados in listaIdEstados){    
    await obterCidade(1, listaEstados);
    //print(listaEstados);
  };
  
}

Future<void> obterCidade(int id_pais, int id_uf) async {
  var url = 'https://servicodados.ibge.gov.br/api/v1/localidades/estados/${id_uf}/distritos';
  var dio = Dio();
  var response = await dio.get(url.toString());
  List<dynamic> respDataCidade = response.data;
  //print(response.statusCode);
  if(response.statusCode == 200){
    //print(respDataCidade[0]);
  }else{
    print(response.statusCode);
  }  
  await Future.forEach(respDataCidade, (element) async {
    //print('id_uf = ${id_uf} id_cidade = ${element['id']} e nome_cidade = ${element['nome']}');
    await salvar_db.salvarCidade(id_pais, id_uf, element['id'], element['nome']);
  });  
}